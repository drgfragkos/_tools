# CVRT-FortiGate-Logs GUI

**Fast, reliable conversion of Fortinet / FortiGate firewall logs to Excel-ready CSV — built for DFIR practitioners.**

Version 2.0.0 · © 2026 [@drgfragkos](https://github.com/drgfragkos) · Windows x64

---

## What it does

FortiGate (and FortiAnalyzer-exported) log files store every event as a long
line of `key=value` pairs — powerful for machines, painful for humans.
**CVRT-FortiGate-Logs GUI** converts one or many `.log` files into clean,
properly formatted CSV files that open directly in Microsoft Excel, with
every log field organized into its own column. Drop the files in, press
**Convert All**, open the results in Excel, start investigating.

It is designed for real incident-response workloads: log files of **1 GB+
with millions of lines** convert quickly, with flat memory usage, without
freezing the interface, and without ever hanging or crashing on malformed
input.

## Key features

- **Drag & drop** one or more `.log` files (or whole folders) onto the
  window — or use *File → Add Log Files*. Loaded files appear in a matrix
  showing size, row count, dates, and live conversion status.
- **One-click batch conversion** with a live progress bar; each file's
  status turns **DONE** as it completes. Conversion runs in the background,
  so the window stays fully responsive, and can be stopped at any time.
- **Every field becomes a column — automatically.** Nothing is hardcoded:
  the tool discovers whatever fields exist in *your* file, so new FortiGate
  firmware fields or analyst-added fields are picked up without updates.
- **Excel-safe output, always.** Files with more than 1,000,000 rows are
  automatically split into numbered parts (`event_001.csv`,
  `event_002.csv`, …) so every CSV stays below Excel's worksheet row limit.
  Commas, quotes, and special characters inside values are properly
  escaped; output is UTF-8 and opens cleanly in Excel.
- **Nothing is silently lost.** Lines that cannot be parsed are skipped and
  preserved in a companion `<name>_error.csv` file (line number + original
  content) for manual review — essential for evidential integrity.
- **Handles logs from anywhere.** Windows, Linux, or mixed line endings;
  quoted values with spaces; FortiGate's escaped quotes — all handled
  automatically.
- **Dark-themed interface** throughout: window, menus, file matrix,
  activity log, and dialogs.
- **Activity log** records every action with timestamps — loads,
  conversions, warnings, and errors — so you have a trace of what was done.

## Getting started

1. Download `CVRT-FortiGate-Logs-GUI.exe` and place it in any folder.
2. Double-click to launch — no installation required.
3. Drag your `.log` file(s) onto the window.
4. Press **Convert All** (or `F5`).
5. Your CSV files appear in the save directory shown at the bottom of the
   window — double-click that path to open it in Explorer, or change it
   via *File → Set Output Folder*.

By default, converted files are saved next to the application. The tool
remembers your window layout and chosen output folder between sessions
(stored in a small hidden settings file next to the executable).

## Requirements

- Windows 10 / 11 (64-bit)
- .NET Desktop Runtime 10 — if it is missing, Windows will prompt you with
  a download link on first launch

No PowerShell knowledge is needed to use the application.

## Output at a glance

| Input | Output |
| --- | --- |
| `event.log` (fits in one sheet) | `event.csv` |
| `big.log` (2.3M rows) | `big_001.csv`, `big_002.csv`, `big_003.csv` |
| Any file with unparseable lines | additionally `<name>_error.csv` for review |

Existing output files with the same names are overwritten (a warning is
written to the activity log).

## Notes

- **Antivirus false positives:** executables produced from PowerShell
  scripts are occasionally flagged by heuristic antivirus engines. The
  application makes no network connections and modifies nothing outside
  the output folder you choose. If your organization requires it, verify
  the file hash against the published release hash, or run the equivalent
  PowerShell script version from source.
- **About & credits:** *Help → About* shows version and author
  information. (Tip for the curious: `Ctrl` + double-click the logo.)
- Source scripts (CLI and GUI), technical documentation, and build
  instructions are available in the main project repository.

## Disclaimer

This tool is provided "as is", without warranty of any kind. It performs
read-only processing of the input log files; nevertheless, when handling
evidential material, always work on forensic copies in line with your
organization's procedures.

## License & copyright

Copyright © 2026 [@drgfragkos](https://github.com/drgfragkos).
All rights reserved.
