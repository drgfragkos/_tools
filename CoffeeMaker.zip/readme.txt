
Coffee Maker - (c)gfragkos 2001, updated 2010

    CoffeeMaker.exe - The UI for Coffee Maker  
    LPT1cmdargs.exe - The conslole application to send values to the LPT
      LPTbinary.exe - Graphical test application for LPT values
     alarmclock.mp3 - The alarm clock sound for Coffee Maker



The Coffee Maker is capable of executing batch file commands. 

So, you can either start some music when coffee is ready: 
start wmplayer.exe "H:\Music\other\alarmclock.mp3"

or, you can execute any other command you want*: shutdown -s -f -t 0

*This command will turn off your computer.




Enjoy Coffee Maker