
 SlideShowJPGs.exe GENERIC v1.1 - (c) @drgfragkos 2012

 A small utility to Slide-Show jpg files. The default interval is 2 1/2 sec.
 In this version, the user is able to modify interval on the  fly. Using the
 keys f, s, and d, the Slide-Show can go (f)aster, (s)lower or return to its 
 (d)efault speed.  The Slide-Show can be paused,  or resumed, by hitting the
 space bar key. Using the Left or Right arrows, the user is able to navigate
 to the previous or to the next picture respectively.  Using the plus (+) or
 minus (-) keys from the numeric pad the user is able to zoom in or zoom out
 while viewing the pictures. You can use the F11 key to switch the form from
 normal to fullscreen and via versa. If no pictures (JPG files) found in the
 same directory with the application, no picture is displayed. However, if a
 single picture or a number of pictures appear in the working directory, the
 application will start the slide show automatically. If any of the pictures
 are deleted, they are removed from the slide show without interruption.

 This version is the GENERIC version which has the no watermark assigned and
 a logo appearing before starting the actual slide show.



 To Do:
 - Load a custom wallpaper if present
 - Load a custom splashscreen if present
 - Load a custom watermark if present
 - Preset an alternative interval
 